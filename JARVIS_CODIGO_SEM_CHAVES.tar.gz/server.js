const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{URL}=require('node:url');
const Memory=require('./modules/memory'),Bus=require('./modules/bus'),{understand}=require('./modules/intent'),Gateway=require('./modules/gateway'),Planner=require('./modules/planner'),Registry=require('./modules/registry'),Perm=require('./modules/permissions'),SelfAwareness=require('./modules/self-awareness');
const ROOT=__dirname,DATA_DIR=path.join(ROOT,'data'),FILE=path.join(DATA_DIR,'jarvis-data.json'),HOST='127.0.0.1',PORT=Number(process.env.PORT||3000);
fs.mkdirSync(DATA_DIR,{recursive:true});
const initial=()=>({version:10,memories:[],tasks:[],projects:[],plans:[],conversations:[],events:[],approvals:[],settings:{assistantName:'JARVIS',gateway:{},permissions:{...Perm.DEFAULTS}}});
function load(){try{const p=JSON.parse(fs.readFileSync(FILE,'utf8'));return{...initial(),...p,version:10,memories:(p.memories||[]).map(x=>({...x,id:x.id||crypto.randomUUID(),category:Memory.normalizeCategory(x.category)||'operacional'})),tasks:p.tasks||[],projects:p.projects||[],plans:p.plans||[],conversations:p.conversations||[],events:p.events||[],approvals:p.approvals||[],settings:{...initial().settings,...p.settings,permissions:{...Perm.DEFAULTS,...p.settings?.permissions},gateway:{...p.settings?.gateway}}}}catch{return initial()}}
let data=load(),queue=Promise.resolve(),saveCount=0;if(data.settings.gateway?.endpoint&&!data.settings.gateway?.primary){data.settings.gateway={primary:{provider:'Gemini',endpoint:'https://generativelanguage.googleapis.com/v1beta/openai',model:'gemini-2.5-flash',apiKey:''},fallback:{...data.settings.gateway}}}if(data.settings.gateway?.primary?.endpoint?.includes('openrouter.ai'))data.settings.gateway.primary.provider='OpenRouter';
const gateway=new Gateway(data.settings.gateway);
const clean=(v,n=2000)=>typeof v==='string'?v.trim().slice(0,n):'';
function log(type,detail){data.events.push({id:crypto.randomUUID(),type,detail:clean(String(detail||''),300),at:new Date().toISOString()});data.events=data.events.slice(-500);Bus.publish('activity',{type,detail})}
function save(){const snap=JSON.stringify(data,null,2);queue=queue.then(async()=>{saveCount++;if(saveCount===1||saveCount%20===0){const dir=path.join(DATA_DIR,'backups');await fs.promises.mkdir(dir,{recursive:true});const stamp=new Date().toISOString().replace(/[:.]/g,'-');await fs.promises.writeFile(path.join(dir,'jarvis-'+stamp+'.json'),snap,{mode:0o600});const files=(await fs.promises.readdir(dir)).filter(x=>x.endsWith('.json')).sort();for(const old of files.slice(0,Math.max(0,files.length-4)))await fs.promises.unlink(path.join(dir,old));}const tmp=FILE+'.tmp';await fs.promises.writeFile(tmp,snap,{mode:0o600});await fs.promises.rename(tmp,FILE)});return queue}
function send(res,status,obj,type='application/json; charset=utf-8',headers={}){res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self';",...headers});res.end(type.startsWith('application/json')?JSON.stringify(obj):obj)}
function body(req){return new Promise((resolve,reject)=>{let raw='';req.on('data',c=>{raw+=c;if(raw.length>200000){reject(Error('Corpo muito grande'));req.destroy()}});req.on('end',()=>{try{resolve(raw?JSON.parse(raw):{})}catch{reject(Error('JSON inválido'))}});req.on('error',reject)})}
function taskCreate(title,priority='normal'){const t={id:crypto.randomUUID(),title:clean(title,200),status:'pendente',priority:['baixa','normal','alta'].includes(priority)?priority:'normal',createdAt:new Date().toISOString()};data.tasks.push(t);log('task.created',t.title);return t}
function memoryCreate(content,category){const m=Memory.create(content,category);data.memories.push(m);log('memory.created',m.content);return m}
const tools=[
{type:'function',function:{name:'search_memories',description:'Pesquisar memórias do usuário. Use antes de responder perguntas sobre preferências ou fatos pessoais.',parameters:{type:'object',properties:{query:{type:'string',description:'Termo para pesquisa'}},required:['query']}}},
{type:'function',function:{name:'list_pending_tasks',description:'Listar tarefas pendentes.',parameters:{type:'object',properties:{},required:[]}}},
{type:'function',function:{name:'propose_save_memory',description:'Solicitar autorização para salvar uma memória.',parameters:{type:'object',properties:{content:{type:'string'},category:{type:'string',enum:['pessoal','episodica','semantica','operacional','longo_prazo']}},required:['content','category']}}},
{type:'function',function:{name:'propose_create_task',description:'Solicitar autorização para criar uma tarefa.',parameters:{type:'object',properties:{title:{type:'string'},priority:{type:'string',enum:['baixa','normal','alta']}},required:['title']}}},
{type:'function',function:{name:'propose_create_project',description:'Solicitar autorização para criar um projeto.',parameters:{type:'object',properties:{name:{type:'string'},description:{type:'string'}},required:['name']}}},
{type:'function',function:{name:'create_plan',description:'Criar um plano de trabalho em etapas para um objetivo. O plano fica como rascunho para o usuário revisar.',parameters:{type:'object',properties:{goal:{type:'string'}},required:['goal']}}},{type:'function',function:{name:'get_system_status',description:'Consultar capacidades reais, módulos, ferramentas disponíveis e limitações implementadas do Jarvis. Use para perguntas sobre si mesmo.',parameters:{type:'object',properties:{},required:[]}}}
];
async function toolCall(name,args){
 if(name==='get_system_status')return SelfAwareness.buildStatus({gateway:gateway.status(),modules:Registry.modules,data});
 if(name==='search_memories')return Memory.list(data.memories,null,clean(args.query,100)).slice(0,15).map(x=>({content:x.content,category:x.category}));
 if(name==='list_pending_tasks')return data.tasks.filter(x=>x.status!=='concluida').map(x=>({title:x.title,priority:x.priority,status:x.status}));
 if(name==='create_plan'){const p=Planner.makePlan(clean(args.goal,500));data.plans.push(p);log('plan.created',p.goal);return{created:true,plan:p}}
 const mapping={propose_save_memory:{tool:'memory_write',kind:'memory',payload:{content:clean(args.content),category:Memory.normalizeCategory(args.category)||'operacional'}},propose_create_task:{tool:'task_write',kind:'task',payload:{title:clean(args.title,200),priority:args.priority||'normal'}},propose_create_project:{tool:'project_write',kind:'project',payload:{name:clean(args.name,120),description:clean(args.description,500)}}};
 const spec=mapping[name];if(!spec)throw Error('Ferramenta desconhecida');
 const approval={id:crypto.randomUUID(),...spec,status:'pending',createdAt:new Date().toISOString()};
 data.approvals.push(approval);log('approval.requested',name);return{approval_required:true,id:approval.id,action:name,summary:spec.payload};
}
function local(message){
 const i=understand(message);
 if(i.type==='memory.save'){const m=memoryCreate(i.content,i.category);return{reply:'Memória salva: '+m.content,local:true};}
 if(i.type==='task.create'){const t=taskCreate(i.title);return{reply:'Tarefa criada: '+t.title,local:true}}
 if(i.type==='task.list'){const a=data.tasks.filter(x=>x.status!=='concluida');return{reply:a.length?a.map((x,n)=>`${n+1}. ${x.title} (${x.priority})`).join('\n'):'Você não tem tarefas pendentes.',local:true}}
 if(i.type==='memory.list')return{reply:`Tenho ${data.memories.length} memórias. Abra a aba Memória para pesquisar e organizar.`,local:true};
 if(i.type==='greeting')return{reply:'Olá! Estou online. Pode falar normalmente comigo.',local:true};
 if(i.type==='help')return{reply:'Posso conversar com a IA, pesquisar memórias, listar tarefas, criar planos e propor ações. Ações de escrita feitas pela IA precisam da sua aprovação.',local:true};
 return null;
}
function terms(text){const stop=new Set(['que','para','com','uma','umas','uns','dos','das','por','como','isso','essa','esse','aqui','ali','voce','meu','minha','meus','minhas','the','and','you','are']);return (String(text||'').toLocaleLowerCase('pt-BR').normalize('NFD').replace(/[\u0300-\u036f]/g,'').match(/[a-z0-9]{3,}/g)||[]).filter(w=>!stop.has(w))}
function relevantMemories(query,limit=4){
 const words=[...new Set(terms(query))];
 return Memory.list(data.memories).map(m=>{const t=terms(m.content),score=words.reduce((n,w)=>n+(t.includes(w)?2:0),0)+(m.category==='longo_prazo'?0.25:0);return{m,score}}).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||new Date(b.m.updatedAt||b.m.createdAt)-new Date(a.m.updatedAt||a.m.createdAt)).slice(0,limit).map(x=>`[${x.m.category}] ${x.m.content.slice(0,240)}`).join('\n');
}
function selectTools(message){
 const q=String(message).toLocaleLowerCase('pt-BR'),out=[];
 const add=n=>{const t=tools.find(x=>x.function.name===n);if(t&&!out.includes(t))out.push(t)};
 if(/jarvis|voce e|quem e voce|suas capacidade|suas ferramenta|seu sistema|seu modelo|qual ia|qual modelo|status do sistema|o que consegue/.test(q))add('get_system_status');
 if(/lembra|memoria|sobre mim|eu gosto|eu prefiro|meu projeto|minha preferencia|conversamos/.test(q))add('search_memories');
 if(/tarefa|pendente|afazer|a fazer/.test(q))add('list_pending_tasks');
 if(/salva|guarda|lembre|memoriza/.test(q))add('propose_save_memory');
 if(/cria uma tarefa|adiciona uma tarefa|nova tarefa/.test(q))add('propose_create_task');
 if(/cria um projeto|novo projeto|adiciona projeto/.test(q))add('propose_create_project');
 if(/planeja|planejamento|plano|etapas|organiza.*objetivo/.test(q))add('create_plan');
 return out;
}
function compactContext(message){
 const q=String(message).toLocaleLowerCase('pt-BR'),personal=/lembra|memoria|sobre mim|eu gosto|eu prefiro|meu projeto|minha preferencia|conversamos|minha namorada|minha familia|meu irmao|minha ideia|ja falei/.test(q);
 const tasky=/tarefa|pendente|afazer|a fazer|planeja|plano|etapas/.test(q);
 const projecty=/projeto|planeja|plano/.test(q);
 return{mem:personal?relevantMemories(message,4):'',tasks:tasky?data.tasks.filter(x=>x.status!=='concluida').slice(0,8).map(x=>x.title).join('\n'):'',plans:projecty?data.plans.slice(-2).map(x=>x.goal+' ('+x.status+')').join('\n'):''};
}
function asksSystem(message){return /jarvis|voce e|quem e voce|suas capacidade|suas ferramenta|seu sistema|seu modelo|qual ia|qual modelo|status do sistema|o que consegue/.test(String(message).toLocaleLowerCase('pt-BR'))}
async function chat(message){
 const direct=local(message);if(direct){data.conversations.push({user:message,assistant:direct.reply,at:new Date().toISOString(),engine:'local'});return{...direct,engine:'local'}}
 if(!gateway.status().connected)return{reply:'Ainda não há modelo conectado. Configure o AI Gateway.',engine:'local'};
 const c=compactContext(message),status=asksSystem(message)?SelfAwareness.buildStatus({gateway:gateway.status(),modules:Registry.modules,data}):null;
 const system=`Você é JARVIS, assistente pessoal do usuário. Responda em português brasileiro, com clareza e boa qualidade. Seja honesto: não alegue executar ações sem confirmação real. Use somente ferramentas fornecidas nesta chamada. Ações de escrita exigem aprovação; planos são rascunhos. Não invente recursos, memórias ou resultados.${status?'\nESTADO REAL DO SISTEMA: '+JSON.stringify({identity:status.identity,ai:status.ai,modules:status.modules.map(x=>x.name+':'+x.status),tools:status.tools.map(x=>x.name),implemented:status.implemented,notImplemented:status.notImplemented,constraints:status.constraints}):''}${c.mem?'\nMEMÓRIAS RELEVANTES:\n'+c.mem:''}${c.tasks?'\nTAREFAS PENDENTES:\n'+c.tasks:''}${c.plans?'\nPLANOS RECENTES:\n'+c.plans:''}`;
 const history=data.conversations.filter(x=>x.engine!=='local').slice(-2).flatMap(x=>[{role:'user',content:String(x.user||'').slice(0,700)},{role:'assistant',content:String(x.assistant||'').slice(0,900)}]);
 const messages=[{role:'system',content:system},...history,{role:'user',content:message}];
 const availableTools=selectTools(message);const complex=/detalhad|completo|passo a passo|analisa|compare|pesquisa|desenvolv|codigo|arquitetura|estrategia|explica|tudo que falta/.test(message.toLocaleLowerCase('pt-BR'));
 const maxTokens=complex?1500:900;let answer='',pending=[],provider=null,model=null,usage=null;
 for(let round=0;round<2;round++){
  const result=await gateway.complete(messages,availableTools,maxTokens);provider=result.provider;model=result.model;usage=result.usage;const msg=result.message;
  if(!msg.tool_calls?.length){answer=msg.content||'Não recebi uma resposta textual.';break}
  messages.push(msg);
  for(const call of msg.tool_calls){let args={};try{args=JSON.parse(call.function.arguments||'{}')}catch{};const toolResult=await toolCall(call.function.name,args);if(toolResult?.approval_required)pending.push(toolResult);messages.push({role:'tool',tool_call_id:call.id,content:JSON.stringify(toolResult).slice(0,3000)});}
 }
 if(!answer)answer=pending.length?'Preparei ações que precisam da sua aprovação. Veja a seção Aprovações.':'Concluí a etapa de ferramentas.';
 data.conversations.push({user:message,assistant:answer,at:new Date().toISOString(),engine:'ai',provider,model});data.conversations=data.conversations.slice(-80);log('chat.ai',message.slice(0,100));
 return{reply:answer,engine:'ai',provider,model,usage,approvals:pending};
}
const server=http.createServer(async(req,res)=>{const u=new URL(req.url,`http://${HOST}:${PORT}`);try{
 if(req.method==='GET'&&u.pathname==='/api/health')return send(res,200,{status:'online',name:'JARVIS CORE',version:'1.4.0-alpha',uptime:process.uptime(),modules:Registry.modules,gateway:gateway.status(),counts:{memories:data.memories.length,tasks:data.tasks.length,projects:data.projects.length}});
 if(req.method==='GET'&&u.pathname==='/api/capabilities')return send(res,200,SelfAwareness.buildStatus({gateway:gateway.status(),modules:Registry.modules,data}));
 if(req.method==='GET'&&u.pathname==='/api/overview')return send(res,200,{memories:data.memories.length,pending:data.tasks.filter(x=>x.status!=='concluida').length,projects:data.projects.length,approvals:data.approvals.filter(x=>x.status==='pending').length,events:data.events.slice(-12).reverse()});
 if(req.method==='GET'&&u.pathname==='/api/modules')return send(res,200,Registry.modules);
 if(req.method==='GET'&&u.pathname==='/api/memories')return send(res,200,Memory.list(data.memories,Memory.normalizeCategory(u.searchParams.get('category')),clean(u.searchParams.get('q'),100)));
 if(req.method==='POST'&&u.pathname==='/api/memories'){const b=await body(req),c=Memory.normalizeCategory(b.category);if(!clean(b.content)||!c)return send(res,400,{error:'Conteúdo e categoria obrigatórios.'});const x=memoryCreate(clean(b.content),c);await save();return send(res,201,x)}
 if(req.method==='PATCH'&&u.pathname.startsWith('/api/memories/')){const x=data.memories.find(m=>m.id===u.pathname.split('/').pop());if(!x)return send(res,404,{error:'Memória não encontrada.'});const b=await body(req);if(b.content!==undefined)x.content=clean(b.content);if(b.category!==undefined)x.category=Memory.normalizeCategory(b.category)||x.category;x.updatedAt=new Date().toISOString();await save();return send(res,200,x)}
 if(req.method==='DELETE'&&u.pathname.startsWith('/api/memories/')){const id=u.pathname.split('/').pop(),n=data.memories.length;data.memories=data.memories.filter(x=>x.id!==id);if(n===data.memories.length)return send(res,404,{error:'Não encontrada.'});await save();return send(res,200,{deleted:true})}
 if(req.method==='GET'&&u.pathname==='/api/tasks')return send(res,200,data.tasks.slice().reverse());
 if(req.method==='POST'&&u.pathname==='/api/tasks'){const b=await body(req);if(!clean(b.title))return send(res,400,{error:'Título obrigatório.'});const t=taskCreate(b.title,b.priority);await save();return send(res,201,t)}
 if(req.method==='PATCH'&&u.pathname.startsWith('/api/tasks/')){const t=data.tasks.find(x=>x.id===u.pathname.split('/').pop());if(!t)return send(res,404,{error:'Tarefa não encontrada'});const b=await body(req);if(['pendente','em_andamento','concluida'].includes(b.status))t.status=b.status;await save();return send(res,200,t)}
 if(req.method==='GET'&&u.pathname==='/api/projects')return send(res,200,data.projects);
 if(req.method==='POST'&&u.pathname==='/api/projects'){const b=await body(req);if(!clean(b.name))return send(res,400,{error:'Nome obrigatório'});const p={id:crypto.randomUUID(),name:clean(b.name,120),description:clean(b.description,500),status:'ativo',createdAt:new Date().toISOString()};data.projects.push(p);await save();return send(res,201,p)}
 if(req.method==='GET'&&u.pathname==='/api/plans')return send(res,200,data.plans.slice().reverse());
 if(req.method==='GET'&&u.pathname==='/api/approvals')return send(res,200,data.approvals.filter(x=>x.status==='pending').reverse());
 if(req.method==='POST'&&u.pathname.startsWith('/api/approvals/')){const id=u.pathname.split('/').pop(),a=data.approvals.find(x=>x.id===id&&x.status==='pending');if(!a)return send(res,404,{error:'Aprovação não encontrada'});const b=await body(req);if(b.decision!=='approve'&&b.decision!=='reject')return send(res,400,{error:'Decisão inválida'});a.status=b.decision==='approve'?'approved':'rejected';a.resolvedAt=new Date().toISOString();if(b.decision==='approve'){if(a.kind==='memory')a.result=memoryCreate(a.payload.content,a.payload.category);if(a.kind==='task')a.result=taskCreate(a.payload.title,a.payload.priority);if(a.kind==='project'){a.result={id:crypto.randomUUID(),...a.payload,status:'ativo',createdAt:new Date().toISOString()};data.projects.push(a.result)}}log('approval.'+a.status,a.kind);await save();return send(res,200,a)}
 if(req.method==='GET'&&u.pathname==='/api/settings'){const safe=x=>({provider:x?.provider||'',endpoint:x?.endpoint||'',model:x?.model||'',hasKey:!!x?.apiKey});return send(res,200,{gateway:{primary:safe(gateway.settings.primary||gateway.settings),fallback:safe(gateway.settings.fallback||{})}})}
 if(req.method==='POST'&&u.pathname==='/api/settings/gateway'){const b=await body(req);const cleanProvider=x=>({provider:clean(x?.provider,80),endpoint:clean(x?.endpoint,500),model:clean(x?.model,120),apiKey:clean(x?.apiKey,1000)});const primary=cleanProvider(b.primary||b);const fallback=cleanProvider(b.fallback||{});if(primary.endpoint.includes('openrouter.ai'))primary.provider='OpenRouter';for(const x of [primary,fallback])if(x.endpoint&&!/^https:\/\//i.test(x.endpoint))return send(res,400,{error:'Endpoint inválido'});if(!primary.apiKey)primary.apiKey=gateway.settings.primary?.apiKey||gateway.settings.apiKey||'';if(!fallback.apiKey)fallback.apiKey=gateway.settings.fallback?.apiKey||'';data.settings.gateway={primary,fallback};gateway.update(data.settings.gateway);await save();return send(res,200,gateway.status())}
 if(req.method==='POST'&&u.pathname==='/api/chat'){const b=await body(req),m=clean(b.message,4000);if(!m)return send(res,400,{error:'Mensagem vazia'});try{const out=await chat(m);await save();return send(res,200,out)}catch(e){return send(res,502,{error:'Falha na IA: '+clean(e.message,250)})}}
 if(req.method==='POST'&&u.pathname==='/api/restore'){const b=await body(req);const candidate=b?.backup;if(!candidate||typeof candidate!=='object'||!Array.isArray(candidate.memories)||!Array.isArray(candidate.tasks)||!Array.isArray(candidate.projects)||!candidate.settings||typeof candidate.settings!=='object')return send(res,400,{error:'Arquivo de backup inválido ou incompleto.'});await save();data={...initial(),...candidate,memories:candidate.memories,tasks:candidate.tasks,projects:candidate.projects,plans:Array.isArray(candidate.plans)?candidate.plans:[],conversations:Array.isArray(candidate.conversations)?candidate.conversations.slice(-80):[],events:Array.isArray(candidate.events)?candidate.events.slice(-500):[],approvals:Array.isArray(candidate.approvals)?candidate.approvals:[],settings:{...initial().settings,...candidate.settings,permissions:{...Perm.DEFAULTS,...candidate.settings.permissions},gateway:{...candidate.settings.gateway}}};gateway.update(data.settings.gateway);log('backup.restored','Backup restaurado pelo usuário');await save();return send(res,200,{restored:true,counts:{memories:data.memories.length,tasks:data.tasks.length,projects:data.projects.length}})}
 if(req.method==='GET'&&u.pathname==='/api/backup'){await save();return send(res,200,JSON.stringify(data,null,2),'application/json; charset=utf-8',{'Content-Disposition':'attachment; filename="jarvis-alpha-1-backup.json"'})}
 if(req.method==='GET'&&u.pathname==='/')return send(res,200,fs.readFileSync(path.join(ROOT,'public/index.html'),'utf8'),'text/html; charset=utf-8');
 if(req.method==='GET'&&['/app.js','/style.css'].includes(u.pathname))return send(res,200,fs.readFileSync(path.join(ROOT,'public',path.basename(u.pathname)),'utf8'),u.pathname.endsWith('.js')?'text/javascript; charset=utf-8':'text/css; charset=utf-8');
 return send(res,404,{error:'Rota não encontrada'});
 }catch(e){console.error(e);return send(res,500,{error:clean(e.message,200)})}});
server.listen(PORT,HOST,()=>{console.log(`JARVIS CORE Alpha 1.4 disponível em http://${HOST}:${PORT}`);console.log(`Módulos: ${Registry.modules.length} | Gateway: ${gateway.status().connected?'conectado':'não configurado'}`)});
function stop(){server.close(async()=>{await save();process.exit(0)})}process.on('SIGINT',stop);process.on('SIGTERM',stop);
