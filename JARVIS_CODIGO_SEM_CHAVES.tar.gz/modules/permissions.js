const LEVELS={read:1,write:2,critical:3};
const DEFAULTS={memory_read:true,memory_write:true,task_read:true,task_write:true,project_read:true,project_write:false,system_update:false,device_pair:false};
function requiresApproval(tool,settings){return settings?.permissions?.[tool]===false}
module.exports={LEVELS,DEFAULTS,requiresApproval};
