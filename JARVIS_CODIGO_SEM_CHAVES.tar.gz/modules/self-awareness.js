function buildStatus({gateway,modules,data}){
 const tools=[
  {name:'search_memories',status:'available',effect:'Pesquisa memórias por texto'},
  {name:'list_pending_tasks',status:'available',effect:'Lista tarefas pendentes'},
  {name:'create_plan',status:'available',effect:'Cria plano em rascunho'},
  {name:'propose_save_memory',status:'available',effect:'Solicita aprovação para salvar memória'},
  {name:'propose_create_task',status:'available',effect:'Solicita aprovação para criar tarefa'},
  {name:'propose_create_project',status:'available',effect:'Solicita aprovação para criar projeto'}
 ];
 return {
  identity:'JARVIS CORE Alpha 1.1',
  generatedAt:new Date().toISOString(),
  runtime:{server:'online',host:'127.0.0.1',platform:process.platform,node:process.version},
  ai:{connected:gateway.connected,provider:gateway.provider,model:gateway.model,endpointConfigured:gateway.configured},
  modules:modules.map(m=>({id:m.id,name:m.name,version:m.version,status:m.status,dependencies:m.dependencies})),
  tools,
  data:{memories:data.memories.length,tasks:data.tasks.length,pendingTasks:data.tasks.filter(t=>t.status!=='concluida').length,projects:data.projects.length,plans:data.plans.length,pendingApprovals:data.approvals.filter(a=>a.status==='pending').length},
  implemented:[
   'Chat com modelo externo quando AI Gateway está configurado',
   'Memórias em cinco categorias, pesquisa, edição e exclusão pela interface/API',
   'Tarefas: criar, listar, alterar estado',
   'Projetos: criar e listar',
   'Planos em rascunho',
   'Ferramentas de IA para pesquisa e propostas de escrita com aprovação',
   'Registro de módulos, eventos e backup manual JSON',
   'Servidor local limitado a 127.0.0.1'
  ],
  notImplemented:[
   'Backup automático agendado ou antes de cada atualização',
   'Acesso geral ao sistema de arquivos ou execução arbitrária de comandos',
   'Execução autônoma de código e projetos',
   'Voz, wake word e escuta em segundo plano',
   'Sincronização entre dispositivos e pareamento',
   'Criptografia de dados em repouso',
   'Equipe de múltiplas IAs em debate paralelo',
   'Atualização automática e supervisor independente',
   'Diagnóstico profundo da saúde interna de cada módulo'
  ],
  constraints:[
   'A chave do provedor fica armazenada no arquivo JSON local em texto simples.',
   'Mensagens e contexto enviado ao modelo são transmitidos ao provedor configurado.',
   'Ações de escrita propostas pela IA aguardam aprovação humana.',
   'Backup disponível é manual, via endpoint /api/backup.'
  ]
 };
}
module.exports={buildStatus};
