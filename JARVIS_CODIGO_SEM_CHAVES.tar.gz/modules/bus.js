const {EventEmitter}=require('node:events');
class JarvisBus extends EventEmitter{
 publish(topic,payload){this.emit(topic,payload);this.emit('*',{topic,payload})}
 subscribe(topic,fn){this.on(topic,fn);return()=>this.off(topic,fn)}
}
module.exports=new JarvisBus();
