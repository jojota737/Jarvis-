const modules=[
{id:'memory',name:'Memory Engine',version:'1.0.0',status:'active',dependencies:[]},
{id:'planner',name:'Planner',version:'1.0.0',status:'active',dependencies:['memory']},
{id:'gateway',name:'AI Gateway',version:'1.0.0',status:'active',dependencies:[]},
{id:'permissions',name:'Permission Manager',version:'1.0.0',status:'active',dependencies:[]},
{id:'projects',name:'Project Manager',version:'1.0.0',status:'active',dependencies:['memory']},
{id:'tasks',name:'Task Manager',version:'1.0.0',status:'active',dependencies:[]},
{id:'recovery',name:'Recovery & Backup',version:'1.0.0',status:'active',dependencies:[]}
];
module.exports={modules};
