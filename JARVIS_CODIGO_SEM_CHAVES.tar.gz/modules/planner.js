function makePlan(goal){
 const clean=String(goal||'').trim();
 return {id:require('node:crypto').randomUUID(),goal:clean,status:'rascunho',createdAt:new Date().toISOString(),steps:[
  {id:'understand',title:'Entender o objetivo e os critérios de sucesso',status:'pendente'},
  {id:'prepare',title:'Preparar recursos e dividir o trabalho',status:'pendente'},
  {id:'execute',title:'Executar etapas autorizadas',status:'pendente'},
  {id:'verify',title:'Verificar resultados e registrar aprendizados',status:'pendente'}
 ]};
}
module.exports={makePlan};
