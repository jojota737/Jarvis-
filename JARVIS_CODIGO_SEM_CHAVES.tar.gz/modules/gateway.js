
class AIGateway{
 constructor(settings={}){this.settings=settings||{}}
 update(settings){this.settings={...this.settings,...settings}}
 normalize(x){return{provider:x?.provider||'',endpoint:(x?.endpoint||'').trim(),model:(x?.model||'').trim(),apiKey:x?.apiKey||''}}
 status(){
  const primary=this.normalize(this.settings.primary||this.settings);
  const fallback=this.normalize(this.settings.fallback||{});
  const primaryReady=Boolean(primary.endpoint&&primary.model&&primary.apiKey),fallbackReady=Boolean(fallback.endpoint&&fallback.model&&fallback.apiKey);return{connected:primaryReady||fallbackReady,primaryConfigured:primaryReady,provider:primaryReady?(primary.provider||'Gemini'):(fallbackReady?fallback.provider:'Gemini'),model:primaryReady?(primary.model||null):(fallbackReady?fallback.model:null),endpointConfigured:primaryReady,keyPresent:primaryReady,fallback:{configured:fallbackReady,provider:fallback.provider||'Groq',model:fallback.model||null},mode:'primary-with-fallback'};
 }
 async request(config,messages,tools=[]){
  const s=this.normalize(config);if(!s.endpoint||!s.model||!s.apiKey)throw Error('Provedor '+(s.provider||'')+' não está completamente configurado.');
  const base=s.endpoint.replace(/\/+$/,'');const url=base.endsWith('/chat/completions')?base:base+'/chat/completions';
  const headers={'Content-Type':'application/json','Authorization':'Bearer '+s.apiKey};
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),60000);
  try{
   const payload={model:s.model,messages,temperature:0.4,max_tokens:1800};
   if(tools.length){payload.tools=tools;payload.tool_choice='auto'}
   const r=await fetch(url,{method:'POST',headers,body:JSON.stringify(payload),signal:controller.signal});
   const raw=await r.text();let d;try{d=JSON.parse(raw)}catch{throw Error('Resposta inválida de '+s.provider+' ('+r.status+').')}
   if(!r.ok)throw Error(d.error?.message||s.provider+' respondeu HTTP '+r.status);
   const msg=d.choices?.[0]?.message;if(!msg)throw Error('Resposta vazia de '+s.provider);
   return{message:msg,provider:s.provider,model:s.model};
  }finally{clearTimeout(timer)}
 }
 async complete(messages,tools=[]){
  const primary=this.normalize(this.settings.primary||this.settings);
  const fallback=this.normalize(this.settings.fallback||{});
  let firstError;
  try{return await this.request(primary,messages,tools)}
  catch(e){firstError=e}
  if(fallback.endpoint&&fallback.model&&fallback.apiKey){
   try{return await this.request(fallback,messages,tools)}
   catch(e){throw Error('Falha no principal ('+firstError.message+') e na reserva ('+e.message+').')}
  }
  throw firstError;
 }
}
module.exports=AIGateway;
