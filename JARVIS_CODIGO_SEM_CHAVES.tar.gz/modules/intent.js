const Memory=require('./memory');
function understand(input){
 const text=String(input||'').trim(),s=text.toLocaleLowerCase('pt-BR');let m;
 if((m=text.match(/^(?:lembre(?:-se)?(?:\s+que)?|guarde(?:\s+que)?|memorize(?:\s+que)?)\s+(.+)$/i)))return{type:'memory.save',content:m[1],category:'operacional'};
 if((m=text.match(/^(?:crie|criar|adicione|adicionar|registre|registrar)\s+(?:uma\s+)?tarefa(?:\s+para)?\s+(.+)$/i)))return{type:'task.create',title:m[1]};
 if(/^(?:o que tenho pendente|minhas tarefas|mostre minhas tarefas|liste as tarefas|quais tarefas tenho)\??$/i.test(s))return{type:'task.list'};
 if(/^(?:mostre|liste|buscar|procure)\s+(?:minhas\s+)?mem[oó]rias$/i.test(s))return{type:'memory.list'};
 if(/^(oi|olá|ola|bom dia|boa tarde|boa noite|e aí|eai)\b/i.test(s))return{type:'greeting'};
 if(/^(ajuda|o que você faz|o que voce faz)$/i.test(s))return{type:'help'};
 const old=text.match(/^\/lembrar\s+([a-z_áéíóú]+)\s+([\s\S]+)$/i);if(old){const c=Memory.normalizeCategory(old[1]);if(c)return{type:'memory.save',content:old[2],category:c}}
 return{type:'unknown',text};
}
module.exports={understand};
