const crypto=require('node:crypto');
const CATEGORIES=[{id:'pessoal',label:'Pessoal'},{id:'episodica',label:'Episódica'},{id:'semantica',label:'Semântica'},{id:'operacional',label:'Operacional'},{id:'longo_prazo',label:'Longo prazo'}];
const aliases={'pessoal':'pessoal','episodica':'episodica','episódica':'episodica','semantica':'semantica','semântica':'semantica','operacional':'operacional','longo prazo':'longo_prazo','longo_prazo':'longo_prazo'};
const normalizeCategory=v=>typeof v==='string'?aliases[v.trim().toLocaleLowerCase('pt-BR')]||null:null;
function create(content,category='operacional'){const now=new Date().toISOString();return{id:crypto.randomUUID(),content:String(content).trim(),category:normalizeCategory(category)||'operacional',createdAt:now,updatedAt:now}}
function list(items,category=null,q=''){const s=String(q).toLocaleLowerCase('pt-BR');return items.filter(x=>(!category||x.category===category)&&(!s||x.content.toLocaleLowerCase('pt-BR').includes(s))).sort((a,b)=>new Date(b.updatedAt||b.createdAt)-new Date(a.updatedAt||a.createdAt))}
module.exports={CATEGORIES,normalizeCategory,create,list};
