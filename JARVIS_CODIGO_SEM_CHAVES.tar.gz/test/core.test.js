const test=require('node:test'),assert=require('node:assert/strict');
const M=require('../modules/memory'),{understand}=require('../modules/intent'),P=require('../modules/planner'),Perm=require('../modules/permissions'),G=require('../modules/gateway'),R=require('../modules/registry');
test('categorias de memória preservadas',()=>assert.equal(M.create('x','longo prazo').category,'longo_prazo'));
test('intenção em português cria tarefa',()=>assert.equal(understand('Crie uma tarefa para revisar o Jarvis').type,'task.create'));
test('planejador cria quatro etapas',()=>assert.equal(P.makePlan('Reconstruir Jarvis').steps.length,4));
test('permissões têm padrão explícito',()=>assert.equal(Perm.DEFAULTS.project_write,false));
test('gateway não finge conexão',()=>assert.equal(new G().status().connected,false));
test('registro contém módulos essenciais',()=>assert.ok(R.modules.some(x=>x.id==='memory')&&R.modules.some(x=>x.id==='gateway')));
